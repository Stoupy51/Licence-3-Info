
Pour tester faites :

make

./_projet "demo/<nom_du_fichier>"



avec le nom du fichier que vous voulez